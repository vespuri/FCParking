﻿namespace apiCurso.Data
{
    internal interface ILoggerFactory_logger
    {
    }
}