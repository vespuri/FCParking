﻿namespace api
{
    internal class AppDbContext
    {
    }
}