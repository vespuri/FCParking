﻿
namespace apiCurso.ValueObjects
{
    public enum TipoFrete
    {
        CIE,
        FOB,
        SemFrete,
    }
}