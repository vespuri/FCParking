﻿namespace apiCurso.ValueObjects
{
    public enum TipoProduto
    {
        MercadoriaParaRevenda,
        Embalagem,
        Servico,
    }
}