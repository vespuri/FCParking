﻿namespace apiCurso.ValueObjects
{
    public enum StatusPedido
    {
        Analise,
        Finalizado,
        Entregue,
    }
}
